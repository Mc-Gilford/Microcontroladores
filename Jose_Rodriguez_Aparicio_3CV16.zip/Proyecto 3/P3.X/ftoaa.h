/* 
 * File:   ftoaa.h
 * Author: chuch
 *
 * Created on June 20, 2021, 10:30 PM
 */

#ifndef FTOAA_H
#define	FTOAA_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FTOAA_H */

